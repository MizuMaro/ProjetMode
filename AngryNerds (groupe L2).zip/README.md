# ProjetMode
Nouveau départ pour le projet de modélisation du semestre 3.

Composition de l'équipe : 
- AL YASINI Omar 
- BETTE Guillaume 
- DEJONGHE Rémi 
- LEFEBVRE Robin 
- RAES Rémy

Afin de compiler et d'exécuter le programme, vous pouvez configurer votre IDE sur le projet, en indiquant comme dossier source 'ProjetMode/src',
ou bien compiler les classes à la main ; la classe principale à lancer étant 'Lancer.java'.

Si vous n'avez pas la possibilité de compiler le programme, vous pouvez également exécuter le dernier jar ayant été produit ;
ceux-ci se trouvent dans le dossier 'ProjetMode/docs/jar'.