#Angry Birds

	Images enregistr�es en format png, ce format comportant un canal alpha (= g�rant la transparence)
	