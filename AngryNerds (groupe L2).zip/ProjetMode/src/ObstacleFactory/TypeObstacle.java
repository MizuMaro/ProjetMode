package ObstacleFactory;

public enum TypeObstacle {
	ROND,
	CARRE,
	RONDMOUVEMENT,
	CARREMOUVEMENT
}
